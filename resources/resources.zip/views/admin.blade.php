@extends('layout.main')

@section('container')
<h1>ini admin</h1>
@endsection