@extends('layout.main')

@section('container')
<h1>ini customer</h1>
@endsection